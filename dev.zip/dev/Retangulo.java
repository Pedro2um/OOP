import java.lang.ProcessBuilder.Redirect.Type;

import org.w3c.dom.TypeInfo;

public class Retangulo extends FormaGeometrica {
    private Double a, b;
    public Retangulo(Double lado1, Double lado2){
        a = lado1;
        b = lado2;
    }
    public Double getA() {
        return a;
    }
    public Double getB() {
        return b;
    }
    public Double area(){
        return a*b;
    }
    public Double perimetro(){
        return 2.0*a + 2.0*b;
    }
    @Override
    public String toString() {
        return "lado1 = " + a + "\n" + "lado2 = " + b + "\n";
    }
    

}
