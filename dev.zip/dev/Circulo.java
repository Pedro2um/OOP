public class Circulo extends FormaGeometrica{
    private Double raio;

    public Circulo(Double raio){
        this.raio = raio;
    }
    public Double getRaio(){
        return this.raio;
    }
    public Double area(){
        return Math.PI * this.raio * this.raio;
    }
    public Double perimetro(){
        return 2.0 * Math.PI * this.raio;
    }
    @Override
    public String toString(){
        return "tamanho do raio = " + raio;
    }
}
