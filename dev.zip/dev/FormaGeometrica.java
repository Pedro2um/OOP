public abstract class FormaGeometrica {
    public abstract Double area();
    public abstract Double perimetro();
}
