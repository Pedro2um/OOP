public class Triangulo extends FormaGeometrica {
    public Double a = Double.POSITIVE_INFINITY, b = Double.POSITIVE_INFINITY, c = Double.POSITIVE_INFINITY; // lados;

    public static boolean existe(Double lado1, Double lado2, Double lado3){
        if(lado1 > (lado2 + lado3)) return false;
        else if(lado2 > (lado1 + lado3)) return false;
        else if(lado3 > (lado1 + lado2)) return false;
        return true;
    }

    public Triangulo(Double lado1, Double lado2, Double lado3){
        if(existe(lado1, lado2, lado3) == false){
            System.exit(0);
        } // XXX
        a = lado1;
        b = lado2;
        c = lado3;
    }
    public Double getLado1(){
        return a;
    }
    public Double getLado2(){
        return b;
    }
    public Double getLado3(){
        return c;
    }
    public Double perimetro(){
        return a+b+c;
    }
    public Double area(){
        Double p = perimetro() / 2.0;
        return  Math.sqrt(p*(p-a)*(p-b)*(p-c));
    }
    @Override
    public String toString() {
        return "lado1 = " + a + "\n" + "lado2 = " + b + "\n" + "lado3 = " + c + "\n";
    }
}
