

public class Main {
    public static void main(String[] args){
        Triangulo a = new Triangulo(1.0, 1.0,  1.0);
        System.out.println(a);
        System.out.println(a.area() + "\n");

    }
}
