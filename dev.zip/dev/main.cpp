#include <bits/stdc++.h>

typedef struct TR TR;

struct TR{
    int a, b, c;

    int perimetro(){
        return a+b+c;
    }
    
};

int main(){

    TR* meu;


    return 0;
}